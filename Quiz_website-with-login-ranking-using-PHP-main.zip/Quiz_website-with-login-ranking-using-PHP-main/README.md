# QUIZ_PHP
 Quiz webiste with php and sql database



Can be used with XAMPP 
database name- project
import the sql file into XAMPP phpmyadmin
copy all the files into htdocs folder inside the XAMPP installation folder.
Run localhost on browser.


READ project.sql file for database info or import it directly.
